---
title: Streamlit Webrtc Example
emoji: 🌍
colorFrom: purple
colorTo: yellow
sdk: streamlit
sdk_version: 1.26.0
app_file: app.py
pinned: false
license: mit
# https://huggingface.co/docs/hub/spaces-config-reference
---

# streamlit-webrtc-example

Hosted on Streamlit Cloud: [![Open in Streamlit](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://webrtc.streamlit.app/) https://webrtc.streamlit.app/

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/D1D2ERWFG)

<a href="https://www.buymeacoffee.com/whitphx" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/v2/default-yellow.png" alt="Buy Me A Coffee" width="180" height="50" ></a>

[![GitHub Sponsors](https://img.shields.io/github/sponsors/whitphx?label=Sponsor%20me%20on%20GitHub%20Sponsors&style=social)](https://github.com/sponsors/whitphx)

## Deployment notes

[Streamlit Cloud](https://streamlit.io/cloud) automatically triggers the deployment on its CI/CD.
